setwd("C:\\Users\\it24102694\\Desktop\\IT24102694")
#Q1
branch_data<-read.table("Exercise.txt",header = TRUE)

#Q2
attach(branch_data)