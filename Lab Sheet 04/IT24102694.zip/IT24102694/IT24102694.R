setwd("C:\\Users\\User\\Desktop\\IT24102694")
#Q1
branch_data<-read.table("Exercise.txt",header=TRUE,sep = ",")

#Q2
fix(branch_data)
str(branch_data)
attach(branch_data)

#Q3
boxplot(branch_data$Sales_X1,main="Boxplot for sales")

#Q4
summary(Advertising_X2)
IQR(Advertising_X2)
#Q5
get.outliers<-function(x){
  Q1<-quantile(x)[2]
  Q3<-quantile(x)[4]
  iqr<-Q3-Q1
  
  upper_bound<-Q3+1.5*iqr
  lower_bound<-Q1-1.5*iqr
  print(paste("Upper bound=",upper_bound))
  print(paste("Lower bound=",lower_bound))
  print(paste("Outliers=",paste(sort(x[x<lower_bound | x>upper_bound]),collapes=",")))
}
get.outliers(Years_X3)
  
