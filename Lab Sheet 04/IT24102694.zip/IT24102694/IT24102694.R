setwd("C:\\Users\\it24102694\\Desktop\\IT24102694")
#Q1
branch_data<-read.table("Exercise.txt",header = TRUE,sep = ',')

#Q2
head(branch_data)
sapply(branch_data,class)

#Q3
boxplot(branch_data$Sales_X1,main="Boxplot for sales",ylab="sales")

#Q4
print(fivenum(branch_data$Advertising_X2))
IQR(branch_data$Advertising_X2)

#Q5
Find_outliers<-function(x){
  Q1<-quantile (x,0.25)
  Q3<-quantile(x,0.75)
  IQR_val<-Q3 - Q1
  lower_bound<-Q1-1.5*IQR_val
  upper_bound<-Q3+1.5*IQR_val
  outliers<-x[x<lower_bound| x>upper_bound]
  return(outliers)
}

years_outliers<-Find_outliers(branch_data$Years_X3)

print("Outliers in 'Years_X3' variable:\n")
if(length(years_outliers)==0){
  print("No outliers found")
}else{
  print(years_outliers)
}
