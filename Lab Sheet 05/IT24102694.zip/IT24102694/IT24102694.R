setwd("C:\\Users\\User\\Desktop\\IT24102694")
getwd()

shareholders<-read.csv("Data.txt",header=TRUE,sep=",")
fix(shareholders)
attach(shareholders)
names(shareholders)<-c("X1","X2")
attach(shareholders)
#obtain the histogram
hist(X2,main="Histogram for number of shareholders")

histogram <- hist(X2,main = "Histogram of number of shareholders", breaks = seq(130, 270, length = 8), right = FALSE)

#Labsheet 5
getwd()
Delivery_Times<-read.table("Exercise - Lab 05.txt",header = TRUE,sep=",")
names(Delivery_Times)<-c("X3")
attach(Delivery_Times)

#Histogram
histogram2 <- hist(X3, main="Histogram for delivery times", breaks=seq(20, 70, length=9), right=TRUE)




breaks<-round(histogram2$breaks)
Del_freq<-table(X3)
cum_freq<-cumsum(Del_freq)

new<-c()

for(i in 1:length(breaks)){
  if(i==1){
    new[i]=0
  }else{
    new[i]=cum_freq[i-1]
  }
}



#cumulative frequency polygon
plot(breaks, new, type = 'l',
     main = "Cumulative frequency polygon for Delivery_Times",
     xlab = "Delivery Time (X3)", ylab = "Cumulative Frequency",
     ylim = c(0, max(new)))