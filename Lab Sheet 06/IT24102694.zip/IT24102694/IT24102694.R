setwd("C:\\Users\\User\\Desktop\\IT24102694")

#ii. What is the probability that 40 children are cured?
dbinom(40,44,0.92)

#iii. What is the probability that less than or equal to 35 children are cured?
pbinom(35,44,0.92,lower.tail=TRUE)

#iv. What is the probability that at least 38 children are cured?
1 - pbinom(37, 44,0.92,lower.tail = TRUE)

#v. What is the probability that between 40 and 42 (both inclusive) children are cured?
pbinom(42,44,0.92,lower.tail=TRUE)-pbinom(39,44,0.92,lower.tail=TRUE)

#2. Data from the maternity ward in a certain hospital shows that there is a historical average of 5 babies born in this hospital every day.
#i. What is the random variable (X) in the problem?
#no of babies born in hospital on a given day

#ii. What is the distribution of X?
#Here random variable x has poisson distribution with lambda=5

#iii. What is the probability that 6 babies will be born in this hospital tomorrow?
dpois(6,5)

#iv. What about the probability of more than 6 babies be born in this hospital tomorrow?
  ppois(6,5,lower.tail = FALSE)
  
  #Exercise

#i. What is the distribution of X?
#Here,random variable x has binomial distribution with n=50 and p=0.85

#ii. What is the probability that at least 47 students passed the test?
1-pbinom(46,50,0.85,lower.tail = TRUE)

#2. A call center receives an average of 12 customer calls per hour.
#i. What is the random variable (X) for the problem?
#Let x=The number of customer phone calls per hour

#ii. What is the distribution of X?
#Poisson distribution(lambda=12)

#iii. What is the probability that exactly 15 calls are received in an hour?
dpois(15,12)